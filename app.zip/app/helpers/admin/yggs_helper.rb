module Admin::YggsHelper
end
