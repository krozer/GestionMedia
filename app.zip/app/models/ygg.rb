class Ygg < ApplicationRecord
	# Relations
	belongs_to :sub_category, foreign_key: 'sub_category', primary_key: 'code', optional: true
	belongs_to :tmdb, foreign_key: 'tmdb_id', optional: true
  has_and_belongs_to_many :tags

	# Méthode pour associer un Ygg à une entrée TMDB
	def associate_with_tmdb(tmdb_id)
	  tmdb_entry = Tmdb.find_by(id: tmdb_id) # Recherche de l'entrée TMDB
	  if tmdb_entry
      update!(tmdb_id: tmdb_entry.id) # Mise à jour de l'association
		  puts "Ygg #{id} associé à TMDB #{tmdb_entry.title} (ID: #{tmdb_id})"
	  else
		  puts "TMDB ID #{tmdb_id} introuvable." # Gestion des cas où l'ID TMDB n'existe pas
	  end
	end

	# Extract properties from the name field
	def extract_properties_from_name
		if name.present?
			self.annee = name[/(19\d{2}|20\d{2})/, 1]&.to_i
			self.saison = name[/S(?<saison>\d{1,2})(?=\.|\s|E|$)/i, :saison]&.to_i
			self.episode = name[/E(?<episode>\d{1,2})(?=\.|\s|$)/i, :episode]&.to_i
			self.resolution = name[/(1080p|720p|2160p|4K)/i, 1]
			self.langue = name[/(MULTI|TRUEFRENCH|FRENCH|VOSTFR|VOF|VFF|VF2|VFI|VF)/i, 1]&.upcase
			self.codec = name[/(x264|x265|H264|H265|AV1|HEVC)/i, 1]&.upcase
			self.audio = name[/(DTS|DDP|AC3|AAC|E-AC3)/i, 1]&.upcase
			self.canaux = name[/(5\.1|7\.1|2\.0)/, 1]
			self.source = name[/(BluRay|WEB(-)?DL|HDTV|HDRip|WEBRip|BDRIP|NF.WEB|AMZN.WEB|HDLight|HDR|WEB)/i, 1]&.upcase
			# Extraire le titre principal
			self.titre = extract_title_from_name
			# Associate tags for unstructured attributes
			assign_tags_from_database
		end
	end
	def extract_title_from_name
		return nil unless name.present?
	  
		cleaned_name = name.dup
	  
		# Étape 1 : Trouver les limites du titre
		# Identifier la position des éléments qui marquent le début des métadonnées
		metadata_patterns = [
		  /(19\d{2}|20\d{2})/,           # Année
		  /S\d{1,2}/i,
		  /E\d{1,2}/i,          # Saison/Episode
		  /(1080p|720p|2160p|4K)/i,     # Résolution
		  /(MULTI|TRUEFRENCH|FRENCH|VOSTFR|VOF|VFF|VF2|VFI|VF)/i, # Langue
		  /(x264|x265|H264|H265|AV1|HEVC)/i, # Codec
		  /(DTS|DDP|AC3|AAC|E-AC3)/i,    # Audio
		  /(BluRay|WEB(-)?DL|HDTV|HDRip|WEBRip|BDRIP|NF.WEB|AMZN.WEB|HDLight|HDR|WEB)/i, # Source
		  /(PROPER|REPACK|UNRATED|EXTENDED|DIRECTOR.S.CUT|iNTEGRALE|Intégrale|Custom|COMPLETE|iNTERNAL|10bits?)/i # Tags spéciaux
		]
	  
		# Trouver la première occurrence d'un motif à supprimer
		first_metadata_position = metadata_patterns.map { |pattern| cleaned_name =~ pattern }.compact.min
	  
		# Si un motif est trouvé, tronquer la chaîne
		if first_metadata_position
		  cleaned_name = cleaned_name[0...first_metadata_position]
		end
	  
		# Étape 2 : Nettoyage des caractères spéciaux
		cleaned_name.gsub!(/[\[\]\(\)\-_.]/, ' ') # Remplacer les caractères spéciaux par des espaces
		cleaned_name.squeeze!(' ') # Réduire les espaces multiples
		cleaned_name.strip! # Supprimer les espaces en début et fin
	  
		# Étape 3 : Suppression des doublons éventuels
		words = cleaned_name.split
		cleaned_name = words.uniq.join(' ')
	  
		# Étape 4 : Retirer les résidus éventuels en fin de chaîne
		cleaned_name.gsub!(/\s+$/, '')
	  
		cleaned_name
	end
	
	# Associate tags to the current Ygg instance based on tag names found in the name
	def assign_tags_from_database
		tag_patterns = Tag.all.index_by(&:name)
		matching_tags = tag_patterns.values.select do |tag|
			name.match?(Regexp.new(tag.pattern, Regexp::IGNORECASE))
		end
		self.tags = matching_tags
	end
  # Méthode de classe pour extraire les titres
  def self.extract_titles_for_all(limit: nil, offset: nil)
    query = self.all
    query = query.offset(offset) if offset
    query = query.limit(limit) if limit

    query.map do |ygg|
      { id: ygg.id, title: ygg.extract_title_from_name }
    end
  end
    # Méthode de classe pour appliquer extract_properties_from_name à tous les enregistrements
	def self.update_all_properties
	  all.find_each do |ygg|
		  ygg.extract_properties_from_name
		  ygg.save! # Sauvegarde les modifications dans la base de données
		  puts "Mise à jour des propriétés pour : #{ygg.name}"
	  end
	end
	  # Associer Ygg à une entrée TMDb
	def associate_with_tmdb
		tmdb_entry = search_tmdb
		if tmdb_entry
		  self.tmdb_id = tmdb_entry.id
		  save!
		  puts "Ygg #{id} (#{name}) associé à TMDB #{tmdb_entry.title} (ID: #{tmdb_entry.id})"
		else
		  puts "Aucune correspondance TMDB trouvée pour : #{name}"
		end
	end

  # Recherche TMDb pour l'entrée actuelle
  def search_tmdb
    if titre.present?
      case category_name
      when 'Film'
        search = Tmdb::Search.movie(titre)
      when 'Série'
        search = Tmdb::Search.tv(titre)
      else
        puts "Catégorie non prise en charge pour Ygg ID #{id}."
        return nil
      end

      results = search.results

      if results.any?
        best_match = results.first
        puts "Meilleure correspondance pour #{titre} : #{best_match.title} (TMDB ID: #{best_match.id})"
        return best_match
      else
        puts "Aucune correspondance trouvée pour #{titre}."
        return nil
      end
    else
      puts "Titre manquant pour l'enregistrement YGG avec ID #{id}."
      return nil
    end
  end

  # Associer automatiquement tous les enregistrements non liés à TMDb
  def self.link_all_to_tmdb
    where(tmdb_id: nil).find_each do |ygg|
      match = ygg.search_tmdb
      if match
        # Vérifie ou crée une entrée TMDB
        tmdb_entry = Tmdb.find_or_initialize_by(id: match.id)
        if tmdb_entry.new_record?
          tmdb_entry.title = match.title
          tmdb_entry.release_date = match.release_date
          tmdb_entry.overview = match.overview
          tmdb_entry.save!
        end

        # Associer l'entrée TMDB à Ygg
        ygg.update!(tmdb_id: tmdb_entry.id)
        puts "Ygg ID #{ygg.id} associé à TMDB ID #{tmdb_entry.id}."
      end
    end
  end
  private

  # Récupère le nom de la catégorie via la sous-catégorie
  def category_name
    sub_category&.category&.name
  end
end