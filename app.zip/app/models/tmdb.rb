class Tmdb < ApplicationRecord
	self.primary_key = 'id' # Utiliser id (qui est tmdb_id) comme clé primaire
  
	has_many :yggs, foreign_key: 'tmdb_id'
  end
  