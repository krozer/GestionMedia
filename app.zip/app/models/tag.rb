class Tag < ApplicationRecord
	has_and_belongs_to_many :yggs
	validates :name, presence: true, uniqueness: true
	validates :pattern, presence: true
end
